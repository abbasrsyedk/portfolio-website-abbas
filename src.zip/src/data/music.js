const playlists = [
  {
    name: "Vibes 1",
    cover: "https://i.scdn.co/image/ab67706c0000bebb2e48c0f72e4821a32c3348a1",
    embed: "https://open.spotify.com/embed/playlist/6GcKXkc1XR9I1kEcecd7PO?utm_source=generator"
  },
  {
    name: "Vibes 2",
    cover: "https://i.scdn.co/image/ab67706c0000bebb6c7a4b79ac64e3c3f6a87fdb",
    embed: "https://open.spotify.com/embed/playlist/7ba4qjdm7VBbyfBTP5t0Gh?utm_source=generator"
  },
  {
    name: "Vibes 3",
    cover: "https://i.scdn.co/image/ab67706c0000bebb80c41e8471aafae068f68d4c",
    embed: "https://open.spotify.com/embed/playlist/6ldMGCcV9Rsq5z8Zw5cFng?utm_source=generator"
  },
  {
    name: "Vibes 4",
    cover: "https://i.scdn.co/image/ab67706c0000bebb2c1742b8f17c011dd82c5a4d",
    embed: "https://open.spotify.com/embed/playlist/3yfxHGcWjs0OknMHm2qovJ?utm_source=generator"
  },
  {
    name: "Vibes 5",
    cover: "https://i.scdn.co/image/ab67706c0000bebb0aab4b8267c31628bbdfaccc",
    embed: "https://open.spotify.com/embed/playlist/4jdjBRzR36PB37oFGx8KAa?utm_source=generator"
  },
  {
    name: "Vibes 6",
    cover: "https://i.scdn.co/image/ab67706c0000bebb3decc88b5790b1b4fc6e20cb",
    embed: "https://open.spotify.com/embed/playlist/611c4ZkiLTg0eLevJxzZLn?utm_source=generator"
  },
  {
    name: "Vibes 7",
    cover: "https://i.scdn.co/image/ab67706c0000bebb5a4fbd3f3aa3021b6f0dcb50",
    embed: "https://open.spotify.com/embed/playlist/5oNEZXSYnkRoRIwkMukPtY?utm_source=generator"
  },
  {
    name: "Vibes 8",
    cover: "https://i.scdn.co/image/ab67706c0000bebbcb6e91fd1a3c4c5e3fa2c058",
    embed: "https://open.spotify.com/embed/playlist/532BnlwX9uezXf7UzvClUz?utm_source=generator"
  }
];

export default playlists;
