---
title: "Riding Through Kerala’s Backwaters"
date: "2025-09-02"
excerpt: "A journey through God’s Own Country — lush green landscapes, winding roads, and the backwaters that take your breath away."
---

Kerala was one of the most beautiful rides I’ve done so far.  
The roads were smooth, the food was incredible, and the scenery was like something out of a dream.

```js
// Example code block
function ride() {
  console.log("Into the backwaters 🚴");
}
