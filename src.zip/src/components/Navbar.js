import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="fixed top-0 left-0 w-full bg-black bg-opacity-80 text-white z-50 shadow-lg">
      <div className="max-w-6xl mx-auto flex justify-between items-center p-4">
        <Link href="/" className="text-2xl font-bold tracking-wide">
          Abbas 🚴‍♂️
        </Link>
        <div className="space-x-6">
          <Link href="/work">Work</Link>
          <Link href="/projects">Projects</Link>
          <Link href="/life">Life Resume</Link>
          <Link href="/hobbies">Hobbies</Link>
          <Link href="/blog">Blog</Link>
          <Link href="/contact">Contact</Link>
        </div>
      </div>
    </nav>
  );
}
