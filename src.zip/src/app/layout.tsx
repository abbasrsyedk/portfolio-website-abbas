import "./globals.css";
import Link from "next/link";
import PageTransition from "@/components/PageTransition"; // ✅ use client wrapper

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-gradient-to-b from-gray-50 to-gray-100 text-gray-900 antialiased min-h-screen flex flex-col">
        {/* Navbar */}
        <nav className="bg-gray-900 text-white px-8 py-4 flex justify-between items-center shadow-md fixed top-0 w-full z-50">
          <Link href="/" className="text-xl font-bold flex items-center gap-2">
            Abbas 🏍
          </Link>
          <div className="space-x-6">
            <Link href="/work" className="hover:text-orange-400">Work</Link>
            <Link href="/projects" className="hover:text-orange-400">Projects</Link>
            <Link href="/life" className="hover:text-orange-400">Life</Link>
            <Link href="/hobbies" className="hover:text-orange-400">Hobbies</Link>
            <Link href="/contact" className="hover:text-orange-400">Contact</Link>
          </div>
        </nav>

        {/* Page transition */}
        <main className="flex-1 pt-24 pb-16 max-w-6xl mx-auto px-6 w-full">
          <PageTransition>{children}</PageTransition>
        </main>

        {/* Footer */}
        <footer className="bg-gray-900 text-gray-400 py-6 text-center text-sm mt-auto border-t border-gray-700">
          © {new Date().getFullYear()} Abbas — Built with Next.js, TailwindCSS & Framer Motion
        </footer>
      </body>
    </html>
  );
}
