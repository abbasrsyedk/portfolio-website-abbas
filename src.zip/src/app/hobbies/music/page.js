"use client";


import { motion } from "framer-motion";
import playlists from "@/data/music.js";

export default function Music() {
  return (

      <section className="max-w-6xl mx-auto px-6 py-12">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl font-bold mb-8"
        >
          Music 🎶
        </motion.h1>
        <p className="text-gray-400 mb-10">
          Some playlists I enjoy listening to. For more, check out{" "}
          <a
            href="https://open.spotify.com/user/31whcmr4kdewuidatyz5seqjvvka?si=6a9fdbce59fa4f8e"
            target="_blank"
            rel="noopener noreferrer"
            className="text-orange-400 hover:underline"
          >
            my Spotify profile
          </a>.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {playlists.map((playlist, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="rounded-lg overflow-hidden shadow-lg"
            >
              <iframe
                src={playlist.embed}
                width="100%"
                height="352"
                frameBorder="0"
                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                loading="lazy"
                className="rounded-lg"
              ></iframe>
            </motion.div>
          ))}
        </div>
      </section>

  );
}
