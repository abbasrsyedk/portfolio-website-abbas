"use client";

import Link from "next/link";
import hobbies from "@/data/hobbies.json";

export default function Hobbies() {
  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold mb-6">Hobbies</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {hobbies.map((hobby, idx) => (
          <Link
            key={idx}
            href={hobby.link || "#"}
            className="block bg-white rounded-2xl shadow-md hover:shadow-xl transition p-6"
          >
            <h2 className="text-2xl font-semibold mb-2">{hobby.title}</h2>
            <p className="text-gray-600 mb-4">{hobby.desc}</p>

            {hobby.items && (
              <ul className="list-disc list-inside text-gray-700">
                {hobby.items.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            )}

            {hobby.spotifyProfile && (
              <span className="inline-block mt-4 text-indigo-600 hover:underline">
                Listen on Spotify
              </span>
            )}

            {hobby.link && !hobby.items && !hobby.spotifyProfile && (
              <span className="inline-block mt-4 text-indigo-600 hover:underline">
                Read more →
              </span>
            )}
          </Link>
        ))}
      </div>
    </div>
  );
}
