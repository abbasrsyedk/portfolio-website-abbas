"use client";


import { motion } from "framer-motion";
import { useState } from "react";
import steamGames from "@/data/steamGames.js";

export default function Gaming() {
  const [activeTab, setActiveTab] = useState("valorant");

  // Fallback image if a game has no icon
  const fallbackIcon = "/images/games/fallback.jpg"; // Put this in /public/images/games/

  return (

      <section className="max-w-6xl mx-auto px-6 py-12">
        {/* Header */}
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl font-bold mb-6"
        >
          Gaming 🎮
        </motion.h1>
        <p className="text-gray-400 mb-8">
          My profiles — Valorant (tracker.gg) and my Steam library.
        </p>

        {/* Tabs */}
        <div className="flex space-x-4 mb-8">
          <button
            onClick={() => setActiveTab("valorant")}
            className={`px-4 py-2 rounded-lg font-semibold transition ${
              activeTab === "valorant"
                ? "bg-orange-600 text-white"
                : "bg-gray-800 text-gray-300 hover:bg-gray-700"
            }`}
          >
            Valorant
          </button>
          <button
            onClick={() => setActiveTab("steam")}
            className={`px-4 py-2 rounded-lg font-semibold transition ${
              activeTab === "steam"
                ? "bg-orange-600 text-white"
                : "bg-gray-800 text-gray-300 hover:bg-gray-700"
            }`}
          >
            Steam
          </button>
        </div>

        {/* Content */}
        {activeTab === "valorant" && (
          <iframe
            src="https://tracker.gg/valorant/profile/riot/ShutTFU%23pleas/overview?platform=pc&playlist=competitive&season=5adc33fa-4f30-2899-f131-6fba64c5dd3a"
            width="100%"
            height="900"
            className="rounded-lg border-0 shadow-md"
          ></iframe>
        )}

        {activeTab === "steam" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {steamGames.map((game, idx) => (
              <motion.a
                key={idx}
                href={game.link}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="block bg-gray-900 p-4 rounded-lg shadow-md hover:scale-105 transition"
              >
                <img
                  src={game.icon || fallbackIcon}
                  alt={game.name}
                  className="w-full h-32 object-cover rounded mb-3"
                  onError={(e) => (e.currentTarget.src = fallbackIcon)}
                />
                <h3 className="text-lg font-semibold">{game.name}</h3>
                <p className="text-gray-400 text-sm">
                  {game.hours ? `${game.hours} hrs played` : "No data available"}
                </p>
              </motion.a>
            ))}
          </div>
        )}
      </section>

  );
}
