"use client";

// import Layout from "@/components/Layout";
import books from "@/data/books.json";
import { motion } from "framer-motion";
import Star from "@/components/Star";

export default function Reading() {
  const parseRating = (rating) => {
    const num = parseInt(rating, 10);
    return isNaN(num) ? 0 : num;
  };

  const filteredBooks = books.filter((book) => parseRating(book.rating) >= 4);

  const sortedBooks = [...filteredBooks].sort(
    (a, b) => parseRating(b.rating) - parseRating(a.rating)
  );

  return (
    //<Layout>
      <section className="max-w-7xl mx-auto px-6 py-12">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl font-bold mb-8"
        >
          Reading 📚
        </motion.h1>
        <p className="text-gray-400 mb-10">
          A curated shelf of books I rated highly. See more on{" "}
          <a
            href="https://www.goodreads.com/YOUR_USERNAME"
            target="_blank"
            rel="noopener noreferrer"
            className="text-orange-400 hover:underline"
          >
            my Goodreads
          </a>.
        </p>

        {/* Masonry-style layout */}
        <div className="columns-2 sm:columns-3 md:columns-4 gap-6 space-y-6">
          {sortedBooks.map((book, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="break-inside-avoid"
            >
              <div className="bg-gray-900 rounded-lg shadow-md overflow-hidden">
                {/* Cover */}
                {book.cover ? (
                  <img
                    src={book.cover}
                    alt={book.title}
                    className="w-full object-cover rounded-t-lg"
                    onError={(e) => {
                      // Prevent infinite loop by only setting once
                      if (!e.currentTarget.dataset.fallback) {
                        e.currentTarget.src = "/images/books/placeholder.jpg";
                        e.currentTarget.dataset.fallback = "true";
                      }
                    }}
                  />
                ) : (
                  <div className="w-full bg-gray-700 flex items-center justify-center text-gray-400 py-24">
                    No Cover
                  </div>
                )}

                {/* Title + Rating */}
                <div className="p-3 flex items-center justify-between">
                  <h3 className="text-sm font-semibold">{book.title}</h3>
                  <Star rating={book.rating} />
                </div>

                {/* Author */}
                <p className="text-xs text-gray-400 px-3 pb-3">
                  by {book.author}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    //</Layout>
  );
}
