"use client";

import { useEffect, useRef, useState } from "react";
import Lottie from "lottie-react";

export default function Home() {
  const lottieRef = useRef();
  const [progress, setProgress] = useState(0);
  const [bikeAnimation, setBikeAnimation] = useState(null);

  // Load bike.json dynamically from /public
  useEffect(() => {
    fetch("/lottie/Bike.json")
      .then((res) => res.json())
      .then((data) => setBikeAnimation(data))
      .catch((err) => console.error("Failed to load Bike.json:", err));
  }, []);

  // Track scroll progress
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const maxScroll = document.body.scrollHeight - window.innerHeight;
      const newProgress = scrollTop / maxScroll;
      setProgress(Math.min(Math.max(newProgress, 0), 1));
    };
    window.addEventListener("scroll", handleScroll);
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Animate bike with scroll
  useEffect(() => {
    if (lottieRef.current && bikeAnimation) {
      const duration = lottieRef.current.getDuration(true);
      lottieRef.current.goToAndStop(progress * duration, true);
    }
  }, [progress, bikeAnimation]);

  // Path for the bike (flat, no curve)
const getBikePosition = (t) => {
  const x = t * 90; // spread across viewport width
  const y = 60;     // constant height so bike rides straight
  return { x, y };
};


  const { x: bikeX, y: bikeY } = getBikePosition(progress);

  const checkpoints = [
    { name: "Work", pos: 0.15 },
    { name: "Projects", pos: 0.35 },
    { name: "Life", pos: 0.55 },
    { name: "Hobbies", pos: 0.75 },
    { name: "Contact", pos: 0.9 },
  ];

  return (
    <main className="relative w-full h-[500vh] overflow-x-hidden">
      {/* Canva background iframe */}
      <iframe
        src="/canvabackground.html"
        className="fixed top-0 left-0 w-[200vw] h-full -z-10"
        style={{
          transform: `translateX(-${progress * 100}vw)`, // full parallax slide
          transition: "transform 0.05s linear",
        }}
      />

      {/* Bike */}
      {bikeAnimation && (
        <Lottie
          lottieRef={lottieRef}
          animationData={bikeAnimation}
          loop={false}
          autoplay={false}
          style={{
            width: 160,
            height: 160,
            position: "fixed",
            bottom: `${bikeY}px`,
            left: `${bikeX}vw`,
            zIndex: 10,
          }}
        />
      )}

      {/* Checkpoints */}
      {checkpoints.map((cp, idx) => {
        const { x, y } = getBikePosition(cp.pos);
        return (
          <div
            key={idx}
            className="fixed flex flex-col items-center"
            style={{
              left: `${x}vw`,
              bottom: `${y + 100}px`,
              zIndex: 15,
            }}
          >
            <div className="w-12 h-12 rounded-full bg-yellow-400 border-4 border-white shadow-lg shadow-yellow-500"></div>
            <span className="mt-1 text-sm font-bold text-white drop-shadow-lg">
              {cp.name}
            </span>
          </div>
        );
      })}
    </main>
  );
}
