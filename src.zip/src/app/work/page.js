"use client";

export default function Work() {
  return (
    <main className="max-w-6xl mx-auto px-6 py-12">
      <h1 className="text-4xl font-bold mb-6">Work & Skills</h1>
      <p className="text-gray-700 mb-6">
        Microsoft Dynamics 365 Developer with 3+ years of experience in CRM
        optimization, automation, and user experience enhancement. Specialized
        in Power Platform, Canvas Apps UI, Power Automate, and Azure Data
        Engineering.
      </p>

      <a
        href="/resume.pdf"
        download
        className="inline-flex items-center px-4 py-2 mb-12 bg-orange-600 text-white rounded-lg shadow hover:bg-orange-700 transition"
      >
        📄 Download Resume
      </a>

      <h2 className="text-2xl font-bold mb-4">Experience</h2>

      <div className="mb-8">
        <h3 className="text-xl font-semibold">Software Analyst</h3>
        <p className="text-gray-600">Ford Motor Company · Jul 2022 – Present</p>
        <ul className="list-disc list-inside mt-2 text-gray-700">
          <li>
            Automated workflows with Power Automate Cloud Flows, reducing
            manual work for Customer Care Agents.
          </li>
          <li>
            Built & deployed Customer Service Workspace Application for Ford of
            Mexico (Spanish localization).
          </li>
          <li>
            Designed 95+ dashboards/views in Dynamics 365 for customer service
            insights.
          </li>
          <li>
            Developed 5+ ETL pipelines with Azure Data Factory, cutting
            processing time by 50%.
          </li>
        </ul>
      </div>

      <div className="mb-12">
        <h3 className="text-xl font-semibold">Intern (Junior Engineer)</h3>
        <p className="text-gray-600">Ford Motor Company · Feb 2022 – Jun 2022</p>
        <ul className="list-disc list-inside mt-2 text-gray-700">
          <li>Reduced export costs by 50% via Azure Synapse optimizations.</li>
          <li>
            Migrated schema & data using Configuration Migration Tool for better
            deployment.
          </li>
          <li>
            Contributed to CRM solution deployments (workflows, plugins, web
            apps).
          </li>
          <li>
            Promoted to full-time in 5 months for high-impact contributions.
          </li>
        </ul>
      </div>

      <h2 className="text-2xl font-bold mb-4">Skills</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6 text-gray-700">
        <div>
          <h3 className="font-semibold">Cloud & Data</h3>
          <p>Azure Data Factory, Azure Synapse, SQL</p>
        </div>
        <div>
          <h3 className="font-semibold">Power Platform</h3>
          <p>Power Automate, Power Pages, Power BI, Canvas Apps</p>
        </div>
        <div>
          <h3 className="font-semibold">Programming</h3>
          <p>Python, SQL, Dynamics 365, JavaScript, Java</p>
        </div>
        <div>
          <h3 className="font-semibold">ETL & Tools</h3>
          <p>SSMS, Config Migration Tool, Excel</p>
        </div>
      </div>
    </main>
  );
}
