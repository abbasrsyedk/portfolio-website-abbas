"use client";

import tripsData from "@/data/trips.json";
import { useParams } from "next/navigation";
import Image from "next/image";
import { motion } from "framer-motion";

export default function StatePage() {
  const { state } = useParams();
  const stateData = tripsData.find(
    (s) => s.state.toLowerCase() === state.toLowerCase()
  );

  if (!stateData) {
    return (

        <div className="max-w-4xl mx-auto px-6 py-12 text-center">
          <h1 className="text-3xl font-bold">State not found 🚫</h1>
        </div>
    );
  }

  return (

      <section className="max-w-6xl mx-auto px-4 md:px-6 py-12">
        {/* State Header */}
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl font-bold mb-2"
        >
          {stateData.state} Rides 🏍️
        </motion.h1>
        <p className="text-gray-400 mb-10">{stateData.overview}</p>

        {/* Clean Pinterest-Style Masonry Gallery */}
        <div className="columns-1 sm:columns-2 md:columns-3 gap-4 space-y-4">
          {stateData.trips.map((trip, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: idx * 0.05 }}
              className="break-inside-avoid overflow-hidden rounded-lg shadow-md hover:scale-[1.02] transform transition"
            >
              {trip.photos && trip.photos.length > 0 && (
                <Image
                  src={trip.photos[0]}
                  alt={stateData.state}
                  width={800}
                  height={600}
                  className="w-full h-auto object-cover"
                  sizes="(max-width: 768px) 100vw, 33vw"
                  loading="lazy"
                />
              )}
            </motion.div>
          ))}
        </div>
      </section>
 
  );
}
