import Image from "next/image";
import Link from "next/link";
import trips from "@/data/trips.json";

export default function Life() {
  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold mb-4">Life & Travels</h1>
      <p className="mb-8 text-gray-600">
        A glimpse into my trips and explorations across different states.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {trips.map((state, idx) => {
          const firstPhoto =
            state.trips.length > 0 ? state.trips[0].photos[0] : null;
          return (
            <Link
              key={idx}
              href={`/life/${state.state.toLowerCase()}`}
              className="block bg-white rounded-2xl shadow-md hover:shadow-xl transition p-4"
            >
              {firstPhoto && (
                <div className="relative w-full h-40 mb-4 rounded-xl overflow-hidden">
                  <Image
                    src={firstPhoto}
                    alt={state.state}
                    fill
                    className="object-cover"
                  />
                </div>
              )}
              <h2 className="text-xl font-semibold">{state.state}</h2>
              <p className="text-gray-500">{state.overview}</p>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
